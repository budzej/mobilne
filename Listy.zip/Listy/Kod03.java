package Listy;

import java.util.ArrayList;

public class Kod03 {
    public static void main(String[] args) {
        
        ArrayList<String> imiona = new ArrayList<String>();

        imiona.add("Anna");
        imiona.add("Zenon");
        imiona.add(1,"Dariusz");
        imiona.add("Mateusz");
        imiona.add("Grażyna");
        imiona.add("Joanna");
        imiona.add("Adam");

        for(String imie : imiona){
            System.out.println(imie);
        }
        System.out.println("Rozmiar: " + imiona.size());
        if(imiona.contains("Joanna"))
        {
            System.out.println("Joanna jest na liście" + (imiona.indexOf("Joanna")+1));
        }
        else{
            System.out.println("Brak Joanny");
        }

    }
}
