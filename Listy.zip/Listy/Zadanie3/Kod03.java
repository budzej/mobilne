package Listy.Zadanie3;

import java.util.HashMap;
import java.util.Map;

public class Kod03 {
    public static void main(String[] args) {
        Map<String, Integer> osoby = new HashMap<>();

        osoby.put("Jan", 18);
        osoby.put("Karolina", 35);
        osoby.put("Paweł", 6);
        osoby.put("Karol", 92);
        osoby.put("Kuba", 20);

        for (Map.Entry<String, Integer> entry: osoby.entrySet()){
            String imie = entry.getKey();
            int wiek = entry.getValue();

            System.out.println(imie +" ma "+ wiek + " lat");
        }
    }
}
