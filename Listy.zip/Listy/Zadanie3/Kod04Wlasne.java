package Listy.Zadanie3;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Kod04Wlasne {
    public static void main(String[] args) {
        int[] tab = {3,6,1,27,100,5,9,11,2};


        for (int ele : tab){

            System.out.println(ele);
        }
            int druga = znajdzDruga(tab);
        System.out.println("Druga największa: " + druga);

    }
    
    public static int znajdzDruga(int[] liczby){
        int najwieksza = Integer.MIN_VALUE;
        int druganajwieksza = Integer.MIN_VALUE;

        for (int num : liczby){
            if(num > najwieksza){
                druganajwieksza = najwieksza;
                najwieksza=num;
            }else if (num>druganajwieksza && num != najwieksza){
                druganajwieksza= num;
            }
        }
        return druganajwieksza;
    }
}
