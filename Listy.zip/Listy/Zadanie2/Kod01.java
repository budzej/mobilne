package Listy.Zadanie2;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;



public class Kod01 {
public static void main(String[] args) {
    List<String> imiona = new ArrayList<>();

    imiona.add("Jan");
    imiona.add("Adam");
    imiona.add("Anna");
    imiona.add("Mikołaj");
    imiona.add("Alicja");

    System.out.println("Lista imiona: "+ imiona);

    Collections.reverse(imiona);

    for(String imie : imiona){
        System.out.println(imie);
    }
}    
}
