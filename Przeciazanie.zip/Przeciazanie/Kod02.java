import java.util.Scanner;

class Kalkulator{

    public int dodaj(int a, int b){
        return a+b;
    }
    public double dodaj(double a, double b){
        return a+b;
    }
    public int dodaj(String a, String b){
        return Integer.parseInt(a) + Integer.parseInt(b);
    }
}


public class Kod02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Kalkulator kalkulator = new Kalkulator();

        System.out.println("Wybór typu danych dla kalkulatora: ");
        System.out.println("1 - Liczby całkowite int");
        System.out.println("2 - Liczby rzeczywiste float");
        System.out.println("3 - Stringi - liczby w postaci stringa");
        int wybor = scanner.nextInt();

        switch(wybor){
            case 1:
                    System.out.println("Podaj liczbę całkowitą: ");
                    int int1 = scanner.nextInt();
                    System.out.println("Podaj  drugą liczbę całkowitą: ");
                    int int2 = scanner.nextInt();
                    int wynikInt = kalkulator.dodaj(int1, int2);
                    System.out.println("Wynik dodawania liczb całkowitych to " + wynikInt);
                    break;
            case 2:
                    System.out.println("Podaj liczbę zmiennoprzecinkową: ");
                    double d1 = scanner.nextDouble();
                    System.out.println("Podaj  drugą liczbę zmiennoprzecinkową: ");
                    double d2 = scanner.nextDouble();
                    double wynikD = kalkulator.dodaj(d1, d2);
                    System.out.println("Wynik dodawania liczb zmiennoprzecinkowych to " + wynikD);
                    break;
            case 3:
                    System.out.println("Podaj liczbę całkowitą w stringu: ");
                    String str1 = scanner.next();
                    System.out.println("Podaj  drugą liczbę całkowitą w stringu: ");
                    String str2 = scanner.next();
                    int wynikStr = kalkulator.dodaj(str1, str2);
                    System.out.println("Wynik dodawania liczb całkowitych to " + wynikStr);
                    break;
        }
        scanner.close();
    }

}
