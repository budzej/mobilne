import java.util.Scanner;


class Kalkulator{

    public int dodaj(int a, int b){
        return a+b;
    }
    public double dodaj(double a, double b){
        return a+b;
    }
    public double odejmowanie(double a, double b){
        return a-b;
    }
    public int odejmowanie(int a, int b){
        return a-b;
    }
    public double mnozenie(double a, double b){
        return a*b;
    }
    public int mnozenie(int a, int b){
        return a*b;
    }
    public double dzielenie(double a, double b){
        return a-b;
    }
    public int dzielenie(int a, int b){
        return a/b;
    }
}


public class Zadanie {
    
    public static void main(String[] args) {
        
    
    Scanner scanner = new Scanner(System.in);
    Kalkulator kalkulator = new Kalkulator();

    System.out.println("Wybór typu danych dla kalkulatora: ");
    System.out.println("1 - Liczby całkowite int");
    System.out.println("2 - Liczby rzeczywiste float");
    int wybor = scanner.nextInt();


    switch(wybor){
        case 1:
        System.out.println("Podaj liczbę całkowitą: ");
        int int1 = scanner.nextInt();
        System.out.println("Podaj  drugą liczbę całkowitą: ");
        int int2 = scanner.nextInt();

        System.out.println("Wybór typu działania dla kalkulatora: ");
        System.out.println("1 - dodawanie");
        System.out.println("2 - odejmowanie");
        System.out.println("3 - mnozenie");
        System.out.println("4 - dzielenie");
        int wybor2 = scanner.nextInt();

        switch(wybor2){
            case 1:
                    int wynikInt = kalkulator.dodaj(int1, int2);
                    System.out.println("Wynik dodawania liczb całkowitych to " + wynikInt);
                    break;
    
    }
        break;
    }
}
}